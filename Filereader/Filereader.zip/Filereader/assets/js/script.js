//****************************************** */
//FORM EVENT

// let input = document.querySelector(".myinput")
// console.log(input)
// input.onblur = function(){
//     console.log("this the blur event")
// }

// input.onfocus = function(){
//     console.log("this the Focus Event")
// }

// let select = document.querySelector(".mySelect")

// select.onchange = function(){
//     console.log("this on change event")
// }
// select.onchange = function(){
//     console.log(this)
// }

// input.oninput = function(){
//     console.log(this.value)
// }

// let list = document.querySelector(".list")
// input.oninput = function(){
//         if(this.value != ""){
//                 let li = document.createElement("li");
//     li.className = "list-group-item"
//     li.innerText = this.value
//     list.append(li)
//         }
// }

// let form = document.querySelector("form");
// form.onsubmit = function(e){
//     e.preventDefault();
//     console.log(input.value)
// }

//******************************************* */
//DRAG and DROP events

// let items = Array.from(document.querySelectorAll(".Item"))

// items.forEach(item=> {
//     item.addEventListener("drag", ()=>{
//             console.log("drag")
//     })
// })
//**************************************************** */
// let items = Array.from(document.querySelectorAll(".Item"))
// let zones = Array.from(document.querySelectorAll(".DragZones"))
// let droplist = document.querySelector(".dropList")

// items.forEach(item=> {
//     item.addEventListener("dragstart", (e)=>{
//         e.dataTransfer.setData("text", e.target.id)
//         //e.dataTransfer.setData("text", e.target.id)
       
//            // console.log(e.target.id)
//             console.log("drag started")
//     })
//     item.addEventListener("dragend", (e)=>{
//        // console.log(e.dataTransfer.getData("text"));
//         console.log("drag ended");
//     })
// })

// zones.forEach(zone=>{
//     zone.addEventListener("dragenter", (e)=>{
//         console.log("Entered Drag zones")
//     })

//     zone.addEventListener("dragleave", ()=>{
//         console.log("Leaved Drag zones");
//     })
//         zone.addEventListener("dragover", (e)=>{
//         e.preventDefault()
//            // console.log("item navigating on drop zone")
//         })
    
//     zone.addEventListener("drop", (e)=>{
//         e.preventDefault();
//         let dataid = e.dataTransfer.getData("text");
//         let droppedItem = document.getElementById(dataid)
//         zone.appendChild(droppedItem)
//         console.log("dropped")
//         //console.log();    
//     })
    

// })

//****************************************** */
//Drag and Drop Eaxmple not finished

// let colors = Array.from(document.querySelectorAll(".colorCircle"));

// let dropZone = document.querySelector("dropCircle");

// colors.forEach(color=>{
//     const redd = color.getAttribute("data-red")
//     const greenn  =color.getAttribute("data-green")
//     const bluee = color.getAttribute("data-blue")

//     console.log(redd, greenn, bluee)
// })

// let upload = document.querySelector("#upload")
// let images = document.querySelector(".images");
// // upload.addEventListener("click", ()=>{
// //     console.log("clicked")
// // })

// upload.addEventListener("change", (e)=>{
//     let files = Array.from(e.target.files)
//     files.forEach(file=>{
//         //console.log(file)
//         ShowImage(file)
//     })
// })

// function ShowImage(file){

//    // console.log(file.type)
//     if(file.type != "image/png" && file.type != "image/jpeg" && file.type != "image/jpg"){
//         alert("Please select a image format Picture")
//         return;
//     }
//     let fileReader = new FileReader();
//     fileReader.readAsDataURL(file);
//     fileReader.addEventListener("loadend", ()=>{
//         let col2 = document.createElement("div")
//         col2.className="col-lg-2 bordered mt-3"
//         let img = document.createElement("img");
//         img.src = fileReader.result;
//         img.style.width = "100%";
//         let btn = document.createElement("button")
//         btn.className="btn btn-outline-danger"
//         btn.innerText = "Delete"
       
       
//         col2.appendChild(img)
//         col2.appendChild(btn)
//         btn.onclick = function(){
//             let conf = confirm("Do you want to dalete this file")
//             if(conf){
//                 col2.remove();
//             }
            
//         }
//         images.append(col2)
//     })
// }

//****************************** */
// Drag andr Drop File

let btnfile = document.querySelector(".choosefile");
let inputfile = document.querySelector(".getfile");
let droparea = document.querySelector(".dropArea");
// console.log(btnfile);
// console.log(inputfile);
btnfile.onclick = function(){
    inputfile.click();
}

droparea.addEventListener("dragover", (e)=>{
    e.preventDefault();
})

droparea.addEventListener("drop", (e)=>{
    e.preventDefault();
    let files = Array.from(e.dataTransfer.files);
    files.forEach(file=>{
        ShowImage(file)
    })
    

})


