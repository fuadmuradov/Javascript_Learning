//****************************************** */
//FORM EVENT

// let input = document.querySelector(".myinput")
// console.log(input)
// input.onblur = function(){
//     console.log("this the blur event")
// }

// input.onfocus = function(){
//     console.log("this the Focus Event")
// }

// let select = document.querySelector(".mySelect")

// select.onchange = function(){
//     console.log("this on change event")
// }
// select.onchange = function(){
//     console.log(this)
// }

// input.oninput = function(){
//     console.log(this.value)
// }

// let list = document.querySelector(".list")
// input.oninput = function(){
//         if(this.value != ""){
//                 let li = document.createElement("li");
//     li.className = "list-group-item"
//     li.innerText = this.value
//     list.append(li)
//         }
// }

// let form = document.querySelector("form");
// form.onsubmit = function(e){
//     e.preventDefault();
//     console.log(input.value)
// }

//******************************************* */
//DRAG and DROP events

// let items = Array.from(document.querySelectorAll(".Item"))

// items.forEach(item=> {
//     item.addEventListener("drag", ()=>{
//             console.log("drag")
//     })
// })
//**************************************************** */
// let items = Array.from(document.querySelectorAll(".Item"))
// let zones = Array.from(document.querySelectorAll(".DragZones"))
// let droplist = Array.from(document.querySelector(".dropList"))

// items.forEach(item=> {
//     item.addEventListener("dragstart", (e)=>{
//         e.dataTransfer.setData("text", e.target.id)
//         //e.dataTransfer.setData("text", e.target.id)
       
//            // console.log(e.target.id)
//             console.log("drag started")
//     })
//     item.addEventListener("dragend", (e)=>{
//        // console.log(e.dataTransfer.getData("text"));
//         console.log("drag ended");
//     })
// })

// zones.forEach(zone=>{
//     zone.addEventListener("dragenter", (e)=>{
//         console.log("Entered Drag zones")
//     })

//     zone.addEventListener("dragleave", ()=>{
//         console.log("Leaved Drag zones");
//     })
//         zone.addEventListener("dragover", ()=>{
//            // console.log("item navigating on drop zone")
//         })
    
//     zone.addEventListener("drop", (e)=>{
        
//         let dataid = e.dataTransfer.getData("text");
//         let droppedItem = document.getElementById(dataid)
//         droplist.append(droppedItem)
//         console.log("dropped")
//         //console.log();    
//     })
    

// })
