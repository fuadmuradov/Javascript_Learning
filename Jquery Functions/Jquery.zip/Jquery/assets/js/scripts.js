// $(document).ready(function(){
    // $("p").click(function(){
    //     $(this).hide();
    // });

    // $("p").click(function(){
    //     $(this).fadeOut()
    // })

    // $("p").click(function(){
    //     $(this).fadeIn()
    // })
    // $(".box .title").click(function(){
    //     $(this).fadeOut()
    // })

// $(".box .title").click(function(){
//     $("p").fadeToggle(3000)
// })

    // $(".btn").click(function(){
    //     $(".box").slideUp("fast")
    // })

    // $(".btn").click(function(){
    //     $(".box").slideUp("fast")
    // })

// });

$(document).ready(function(){
    // $(".title-icon").click(function(){
    //     let next = $(this).next();
    //     let icon = $(this).children(".icon")
    //     $(".article").not(next).slideUp();
    //     $(this).next().slideToggle();
    //     $("icon").not($(this).children(".icon")).removeClass("active")
    //     icon.slideToggle("active")
    // })

    //console.log($(".box .section").attr("data-id"))
    // console.log($(".box .section").attr("data-id", "notimportant"))

    let section = $(".box .section");
    // section.removeProp("data-id")
    //console.log(section.prop("data-id"))
    
    // section.addClass("test")
    // section.toggleClass("section")

    // $("input").keypress(function(){
    //     console.log($(this).val())
    // })

    // let style={
    //     color:"white",
    //     backgroundColor:"yellow",
    //     fontsize:"35px"
    // }

    //     section.css(style)

    // console.log(section.height())
    // console.log(section.innerHeight())
    // console.log(section.outerHeight())

    // console.log(section.offset())
    // console.log(section.offsetParent())
    console.log(section.position())
})